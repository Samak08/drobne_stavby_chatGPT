// Handle login, register, logout, and homepage updates
document.addEventListener("DOMContentLoaded", () => {
  const authArea = document.getElementById("auth-area");
  if (authArea) {
    fetch("/api/me").then(res => res.json()).then(user => {
      if (user && user.id) {
        authArea.innerHTML = \`Hello, \${user.username} <button id="logout-btn">Logout</button>\`;
        document.getElementById("logout-btn").addEventListener("click", () => {
          fetch("/api/logout", { method: "POST" }).then(() => location.reload());
        });
        loadOrders();
      } else {
        authArea.innerHTML = '<a href="/login">Login</a> | <a href="/register">Register</a>';
      }
    });
  }

  const loginForm = document.getElementById("login-form");
  if (loginForm) {
    loginForm.addEventListener("submit", async e => {
      e.preventDefault();
      const formData = new FormData(loginForm);
      const body = Object.fromEntries(formData.entries());
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (res.ok) location.href = "/";
      else alert("Login failed");
    });
  }

  const registerForm = document.getElementById("register-form");
  if (registerForm) {
    registerForm.addEventListener("submit", async e => {
      e.preventDefault();
      const formData = new FormData(registerForm);
      const body = Object.fromEntries(formData.entries());
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (res.ok) location.href = "/";
      else alert("Register failed");
    });
  }
});

async function loadOrders() {
  const res = await fetch("/api/orders");
  if (!res.ok) return;
  const data = await res.json();
  const ordersList = document.getElementById("orders-list");
  if (ordersList) {
    ordersList.innerHTML = data.orders.map(o =>
      \`<li>\${o.text_field} (\${o.phone}) at [\${o.latitude}, \${o.longitude}]</li>\`
    ).join("");
  }
}
